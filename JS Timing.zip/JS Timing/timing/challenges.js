// ================================
// JavaScript Timing Challenges
// ================================

// -----------------------------------------------
// Challenge 1: Basic Timeout
// Use setTimeout to log "Hello after 2 seconds!" after exactly 2000 milliseconds.

function sayHello() {
    console.log("Hello after 2 seconds!");
}
setTimeout(sayHello, 2000); // js uses ms!!


// -----------------------------------------------
// Challenge 2: Countdown
// Write a countdown from 3 to 1 using three setTimeout calls.
// Each number should appear one second apart in the console.

function three(){
  console.log("3")
}
function two(){
  console.log("2")
}
function one(){
  console.log("1")
}

setTimeout(three, 1000);
setTimeout(two, 2000);
setTimeout(one, 3000);


// -----------------------------------------------
// Challenge 3: Repeating Message
// Use setInterval to log "Still going..." every second.
// After 5 seconds, stop the interval using clearInterval.

function going(){
    console.log("Still going...")
}

let five = setInterval(going, 1000);
setTimeout(() => clearInterval(five), 5000);




// -----------------------------------------------
// Challenge 4: Delayed Color Change
// Create a <div> in your HTML file with id="box". Put some text in it.
// After 3 seconds, change its background color to blue using setTimeout.

function changeBoxToBlue(){
    let box = document.getElementById("box");
    box.style.backgroundColor = "#0000ff";
}

setTimeout(changeBoxToBlue, 3000);



// -----------------------------------------------
// Challenge 5: Flashing Box
// Create a <div> in your HTML file with id="box2". Put some text in it.
// Using setInterval, make the same box’s background color toggle
// between red and white every half second (500 ms).
// Add a setTimeout to stop the flashing after 5 seconds... or when you click on it!

let isRed = false; 


function toggleColorOfBox2(){
let box2= document.getElementById("box2");

    console.log("changed it!");

    if(isRed) {
      box2.style.backgroundColor = "#ffffff"
    }else {
      box2.style.backgroundColor = "#ff3355"
    }

    isRed = !isRed;

}

setInterval(toggleColorOfBox2, 500);


